#include "b_resultui.h"
#include "ui_b_resultui.h"

#include<QDebug>

B_ResultUI::B_ResultUI(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::B_ResultUI)
{
    ui->setupUi(this);
    this->setGeometry(700,300,1000,600);//起始位置
    this->setFixedSize(1000,600);
    setWindowIcon(QIcon(":/icon/icon/favorite.png")); //程序图标
    setWindowTitle("Thermal effects results");

    //初始化标签容器
    for(int i=0;i<10;i++)
    {
        this->resValue[i]=NULL;
        this->resPercentage[i]=NULL;
        this->boltFig[i]=NULL;
    }
}

B_ResultUI::~B_ResultUI()
{
    delete ui;
}

void B_ResultUI::setData(int *arr)
{
    this->resArr=arr;
}

void B_ResultUI::drawFig(int boltNum, int lapType)
{
    this->boltNum=boltNum;

    //要用指针新建Qlabel对象，因为临时对象不在图片上显示
    int boltAreaLen=(300/boltNum)*(boltNum-1)+50*boltNum;
    int boltBegin_x=(900-boltAreaLen)/2;
    for(int i=0;i<boltNum;i++)
    {
        QLabel *oneBolt=new QLabel(ui->result_fig);
        this->boltFig[i]=oneBolt;
        oneBolt->setStyleSheet(QString("background-color: rgb(200,200,200)"));
        oneBolt->setGeometry(boltBegin_x+(300/boltNum+50)*i,50,50,300);
        oneBolt->show();
    }

    int mixLen=50*boltNum+(300/boltNum)*(boltNum-1)+(300/boltNum)*2; //重叠区域长度
    if(mixLen>=800)
    {
        mixLen=800;
    }
    int plateLen=(800-mixLen)/2+mixLen;
    upPlate=new QLabel(ui->result_fig);
    upPlate->setStyleSheet(QString("background-color: rgb(152,181,237)"));
    upPlate->setGeometry(50,50,plateLen,50);
    upPlate->show();
    midPlate=new QLabel(ui->result_fig);
    midPlate->setStyleSheet(QString("background-color: rgb(238,209,115)"));
    midPlate->setGeometry(850-plateLen,300,plateLen,50);
    if(lapType==2)
    {
        midPlate->setGeometry(850-plateLen,175,plateLen,50);
        downPlate=new QLabel(ui->result_fig);
        downPlate->setStyleSheet(QString("background-color: rgb(152,181,237)"));
        downPlate->setGeometry(50,300,plateLen,50);
        downPlate->show();

    }
    midPlate->show();

    for(int i=0;i<boltNum;i++)
    {
        QLabel *oneLab=new QLabel(ui->result_fig);
        this->resValue[i]=oneLab;
        //oneLab->setAttribute(Qt::WA_TranslucentBackground);//标签透明
        //oneLab->setStyleSheet("background:transparent"); //方法二
        oneLab->setGeometry(boltBegin_x+(300/boltNum+50)*i,160,90,50);
        //oneLab->setText("9999N");
        oneLab->setFont(QFont("等线",12,QFont::Bold)); //设置字体

        QLabel *oneLab2=new QLabel(ui->result_fig);
        this->resPercentage[i]=oneLab2;
        oneLab2->setGeometry(boltBegin_x+(300/boltNum+50)*i,210,70,50);
        //oneLab2->setText("24.1%");

        if(lapType==2)
        {
            oneLab->setGeometry(boltBegin_x+(300/boltNum+50)*i,100,70,40);
            oneLab2->setGeometry(boltBegin_x+(300/boltNum+50)*i,140,70,30);
        }
        oneLab->show();
        oneLab2->show();
    }

    this->showData();
}

void B_ResultUI::showData()
{
    for(int i=0;i<this->boltNum;i++)
    {
        this->resValue[i]->clear();
        this->resPercentage[i]->clear();
    }
    if(this->showValue)
    {
        for(int i=0;i<this->boltNum;i++)
        {
            this->resValue[i]->setText(QString("%1N").arg(QString::number(this->resArr[(dataType-1)*boltNum+i])));
        }
    }
    if(this->showPercentage)
    {
        int dataSum=0;
        for(int i=0;i<this->boltNum;i++)
        {
            int tempInt=qAbs(this->resArr[(dataType-1)*boltNum+i]); //取绝对值
            dataSum+=tempInt;
        }
        if(dataSum==0)
        {
            for(int i=0;i<this->boltNum;i++)
            {
                this->resPercentage[i]->setText(QString("0.0%"));
            }
            return;
        }
        double sumF=dataSum;//整数转浮点数

        double tempPercent=1.2;
        for(int i=0;i<this->boltNum;i++)
        {
            tempPercent=qAbs(100*this->resArr[(dataType-1)*boltNum+i]/sumF);
            //qDebug()<<tempPercent;
            QString tempStr=QString::number(tempPercent,'f',1);
            this->resPercentage[i]->setText(QString("%1%2").arg(tempStr,"%"));
        }
    }

}


//-------五个按钮
void B_ResultUI::on_rad_data1_clicked(bool checked)
{
    if(checked)
    {
        this->dataType=1;
        this->showData();
    }
}

void B_ResultUI::on_rad_data2_clicked(bool checked)
{
    if(checked)
    {
        this->dataType=2;
        this->showData();
    }
}

void B_ResultUI::on_rad_data3_clicked(bool checked)
{
    if(checked)
    {
        this->dataType=3;
        this->showData();
    }
}

void B_ResultUI::on_cb_showValue_clicked(bool checked)
{
    if(checked)
    {
        this->showValue=true;
    }
    else
    {
        this->showValue=false;
        this->showPercentage=true;
        ui->cb_showPercentage->setChecked(true);
    }
    this->showData();
}

void B_ResultUI::on_cb_showPercentage_clicked(bool checked)
{
    if(checked)
    {
        this->showPercentage=true;
    }
    else
    {
        this->showPercentage=false;
        this->showValue=true;
        ui->cb_showValue->setChecked(true);
    }
    this->showData();
}
