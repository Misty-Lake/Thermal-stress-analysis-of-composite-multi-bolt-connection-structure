#ifndef A_MAINWINDOW_H
#define A_MAINWINDOW_H

#include <QMainWindow>

//Calling Python's libraries
#include <QCoreApplication>
#include <Python.h> //No error means the call was successful

#include<QPlainTextEdit>
#include"b_resultui.h"

QT_BEGIN_NAMESPACE
namespace Ui { class A_MainWindow; }
QT_END_NAMESPACE

class A_MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    A_MainWindow(QWidget *parent = nullptr);
    ~A_MainWindow();

    int boltNum=2;
    int lapType=1;
    int boltType=3;
    int BCtype=1;

    void setFig();

    bool dataError=true;
    void checkData();

    //save and read
    QPlainTextEdit *dataSavePlainTextEdit; //save data,not show
    void writeData_intoPlainTextEdit();
    bool saveTextByStream(const QString& aFileName);
    bool openTextByStream(const QString& aFileName);
    void setData_fromPlainTextEdit();

    //call python file
    bool firstUsePy=true;
    PyObject* pConstruct=NULL; //Pointer to class constructor
    int *resArr=NULL; //Array of calculation results

private slots:

    void on_spinBox_boltNum_valueChanged(int arg1);

    void on_checkBox_clicked(bool checked);

    void on_rad_bolt1_clicked(bool checked);

    void on_rad_bolt2_clicked(bool checked);

    void on_rad_bolt3_clicked(bool checked);

    void on_radio_lap1_clicked(bool checked);

    void on_radio_lap2_clicked(bool checked);

    void on_btn_save_clicked();

    void on_btn_read_clicked();

    void on_btn_cal_clicked();


private:
    Ui::A_MainWindow *ui;
};
#endif // A_MAINWINDOW_H
