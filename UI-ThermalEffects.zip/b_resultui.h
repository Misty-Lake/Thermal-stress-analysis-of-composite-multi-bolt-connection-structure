#ifndef B_RESULTUI_H
#define B_RESULTUI_H

#include <QWidget>
#include <QLabel>

namespace Ui {
class B_ResultUI;
}

class B_ResultUI : public QWidget
{
    Q_OBJECT

public:
    explicit B_ResultUI(QWidget *parent = nullptr);
    ~B_ResultUI();

    int boltNum=2;
    int dataType=3;
    bool showValue=true;
    bool showPercentage=true;

    QLabel *resValue[10];
    QLabel *resPercentage[10];
    QLabel *boltFig[10];

    void drawFig(int boltNum,int lapType);
    QLabel *upPlate=NULL;
    QLabel *midPlate=NULL;
    QLabel *downPlate=NULL;

    int *resArr=NULL;
    void setData(int *arr);

    void showData();


private slots:
    void on_rad_data1_clicked(bool checked);

    void on_rad_data2_clicked(bool checked);

    void on_rad_data3_clicked(bool checked);

    void on_cb_showValue_clicked(bool checked);

    void on_cb_showPercentage_clicked(bool checked);

private:
    Ui::B_ResultUI *ui;
};

#endif // B_RESULTUI_H
