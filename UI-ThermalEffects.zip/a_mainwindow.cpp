#include "a_mainwindow.h"
#include "ui_a_mainwindow.h"

//与文件读写相关的库
#include    <QDir>
#include    <QFileDialog>
#include    <QTextStream>
#include    <QTextDocument>
#include    <QTextBlock>

#include<QImage> //插入图像
#include<QPixmap>

#include<QDebug>
#include <QButtonGroup>
#include<QTimer>

#pragma comment(lib,"python39.lib")//防止重复调用第三方库

A_MainWindow::A_MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::A_MainWindow)
{
    ui->setupUi(this);
    this->setGeometry(100,50,1000,800);//起始位置
    this->setFixedSize(1000,800);
    setWindowIcon(QIcon(":/icon/icon/column-3.png")); //程序图标
    setWindowTitle("Thermal effect calculation software");

    QButtonGroup *myGroup = new QButtonGroup;
    myGroup->addButton(ui->radio_lap1,0);
    myGroup->addButton(ui->radio_lap2,1);
    myGroup->setExclusive(true);
    QButtonGroup *myGroup2 = new QButtonGroup;
    myGroup2->addButton(ui->rad_bolt1,0);
    myGroup2->addButton(ui->rad_bolt2,1);
    myGroup2->addButton(ui->rad_bolt3,2);
    myGroup2->setExclusive(true);

    ui->radio_lap1->setChecked(true);
    this->setFig();

    dataSavePlainTextEdit=new QPlainTextEdit(this);
    dataSavePlainTextEdit->hide();

}

A_MainWindow::~A_MainWindow()
{
    delete ui;
}

//___________上半区域按钮
//1-改变钉数量
void A_MainWindow::on_spinBox_boltNum_valueChanged(int arg1)
{
    this->boltNum=arg1;
}

//2-改变搭接类型
void A_MainWindow::setFig()
{
    QImage Image;
    if(this->lapType==1)
    {
        Image.load(":/fig/figure/single lap.png");
    }
    else
    {
        Image.load(":/fig/figure/double lap.png");
    }
    QPixmap pixmap = QPixmap::fromImage(Image);
    int width = ui->label_fig1->width();
    int height = ui->label_fig1->height();
    QPixmap fitpixmap = pixmap.scaled(width, height, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);  // 饱满填充
    //QPixmap fitpixmap = pixmap.scaled(width, height, Qt::KeepAspectRatio, Qt::SmoothTransformation);  // 按比例缩放
    ui->label_fig1->setPixmap(fitpixmap);
    ui->label_fig2->setPixmap(fitpixmap);
}

void A_MainWindow::on_radio_lap1_clicked(bool checked)
{
    if(checked==true)
    {
        this->lapType=1;
    }
    this->setFig();
}
void A_MainWindow::on_radio_lap2_clicked(bool checked)
{
    if(checked==true)
    {
        this->lapType=2;
    }
    this->setFig();
}

//3-改变钉类型
void A_MainWindow::on_rad_bolt1_clicked(bool checked)
{
    if(checked==true)
    {
        this->boltType=1;
    }
    //qDebug()<<this->boltType;
}
void A_MainWindow::on_rad_bolt2_clicked(bool checked)
{
    if(checked==true)
    {
        this->boltType=2;
    }
    //qDebug()<<this->boltType;
}
void A_MainWindow::on_rad_bolt3_clicked(bool checked)
{
    if(checked==true)
    {
        this->boltType=3;
    }
    //qDebug()<<this->boltType;
}

//4-改变边界条件
void A_MainWindow::on_checkBox_clicked(bool checked)
{
    if(checked)
    {
        this->BCtype=2;
    }
    else
    {
        this->BCtype=1;
    }
}

//___________保存设置

void A_MainWindow::writeData_intoPlainTextEdit()
{
    this->dataSavePlainTextEdit->appendPlainText(QString("boltNum=%1").arg(QString::number(this->boltNum)));
    this->dataSavePlainTextEdit->appendPlainText(QString("lapType =%1").arg(QString::number(this->lapType)));
    this->dataSavePlainTextEdit->appendPlainText(QString("boltType=%1").arg(QString::number(this->boltType)));
    //每次新增会自动换行

    //P1
    this->dataSavePlainTextEdit->appendPlainText("\nPage-1-geometry and load");
    dataSavePlainTextEdit->appendPlainText(QString("plate_A_width(unit:mm)=%1").arg(ui->LE_pA_W->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("plate_A_thickness(unit:mm)=%1").arg(ui->LE_pA_t->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("plate_B_width(unit:mm)=%1").arg(ui->LE_pB_W->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("plate_B_thickness(unit:mm)=%1").arg(ui->LE_pB_t->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("bolt_diameter(unit:mm)=%1").arg(ui->LE_bolt_D->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("bolt_spacing(unit:mm)=%1").arg(ui->LE_bolt_S->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("externalLoad(unit:N)=%1").arg(ui->LE_P0->displayText()));

    //P2
    this->dataSavePlainTextEdit->appendPlainText("\nPage-2-material and temperature");
    dataSavePlainTextEdit->appendPlainText(QString("plate_A_modulus(unit:MPa)=%1").arg(ui->LE_pA_E->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("plate_A_CTE(unit:e-05/℃)=%1").arg(ui->LE_pA_CTE->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("plate_B_modulus(unit:MPa)=%1").arg(ui->LE_pB_E->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("plate_B_CTE(unit:e-05/℃)=%1").arg(ui->LE_pB_CTE->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("bolt_modulus(unit:MPa)=%1").arg(ui->LE_bolt_E->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("T_start(unit:℃)=%1").arg(ui->LE_T0->displayText()));
    dataSavePlainTextEdit->appendPlainText(QString("T_end(unit:℃)=%1").arg(ui->LE_T1->displayText()));

    this->dataSavePlainTextEdit->appendPlainText("\nTotal:19lines"); //额外空一行
}

bool A_MainWindow::saveTextByStream(const QString &aFileName)
{
    //用QTextStream保存文本文件
    QFile   aFile(aFileName);
    if (!aFile.open(QIODevice::WriteOnly | QIODevice::Text))
        return false;

    QTextStream aStream(&aFile); //用文本流读取文件
//    aStream.setAutoDetectUnicode(true); //自动检测Unicode,才能正常显示文档内的汉字

    QString str=this->dataSavePlainTextEdit->toPlainText(); //转换为字符串

    aStream<<str; //写入文本流
    aFile.close();//关闭文件

    return  true;
}

void A_MainWindow::on_btn_save_clicked()
{
    this->dataSavePlainTextEdit->clear();//清空旧数据
    this->writeData_intoPlainTextEdit(); //先把参数写到隐藏的文本框内

    QString curPath=QDir::currentPath();//获取系统当前目录
    QString dlgTitle="另存为一个文件"; //对话框标题
    QString filter="文本文件(*.txt);;所有文件(*.*)"; //文件过滤器
    QString aFileName=QFileDialog::getSaveFileName(this,dlgTitle,curPath,filter);
    if (aFileName.isEmpty())
    {
        return;
    }
    this->saveTextByStream(aFileName);
}

//___________读取设置

bool A_MainWindow::openTextByStream(const QString &aFileName)
{//用 QTextStream打开文本文件
    QFile   aFile(aFileName);

    if (!aFile.exists()) //文件不存在
        return false;

    if (!aFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;

    QTextStream aStream(&aFile); //用文本流读取文件
    aStream.setAutoDetectUnicode(true); //自动检测Unicode,才能正常显示文档内的汉字

    this->dataSavePlainTextEdit->clear(); //清除旧数据
    this->dataSavePlainTextEdit->setPlainText(aStream.readAll());

//    ui->textEditStream->clear();//清空
//    while (!aStream.atEnd())
//    {
//        str=aStream.readLine();//读取文件的一行
//        ui->textEditStream->appendPlainText(str); //添加到文本框显示
//    }

    aFile.close();//关闭文件

    return  true;

}

void A_MainWindow::setData_fromPlainTextEdit()
{
    //mid函数。一个int参数表示起始位置到结尾；两个int参数的第二个表示截取长度
    QString lineAll[30];
    for(int i=0;i<21;i++) //原数据共19行，加2空格行
    {
        lineAll[i]=this->dataSavePlainTextEdit->document()->findBlockByLineNumber(i).text();
        //qDebug()<<lineAll[i];
    }

    //截取字符的左边。第a行第b列，lineAll[a-1].mid(b-1)
    this->boltNum=lineAll[0].mid(8).toInt();
    ui->spinBox_boltNum->setValue(this->boltNum);
    //qDebug()<<this->boltNum;
    this->lapType=lineAll[1].mid(9).toInt();
    if(this->lapType==1)
    {
        ui->radio_lap1->setChecked(true);
    }
    else
    {
        ui->radio_lap2->setChecked(true);
    }
    this->boltType=lineAll[2].mid(9).toInt();
    if(this->boltType==1)
    {
        ui->rad_bolt1->setChecked(true);
    }
    else if(this->boltType==2)
    {
        ui->rad_bolt2->setChecked(true);
    }
    else
    {
        ui->rad_bolt3->setChecked(true);
    }
    this->setFig(); //更新示意图

    //P1
    float tempFloat=0.1;
    int tempInt=1;
    tempFloat=lineAll[5].mid(23).toFloat();
    ui->LE_pA_W->setText(QString::number(tempFloat));
    tempFloat=lineAll[6].mid(27).toFloat();
    ui->LE_pA_t->setText(QString::number(tempFloat));
    tempFloat=lineAll[7].mid(23).toFloat();
    ui->LE_pB_W->setText(QString::number(tempFloat));
    tempFloat=lineAll[8].mid(27).toFloat();
    ui->LE_pB_t->setText(QString::number(tempFloat));
    tempFloat=lineAll[9].mid(23).toFloat();
    ui->LE_bolt_D->setText(QString::number(tempFloat));
    tempFloat=lineAll[10].mid(22).toFloat();
    ui->LE_bolt_S->setText(QString::number(tempFloat));
    tempFloat=lineAll[11].mid(21).toFloat();
    ui->LE_P0->setText(QString::number(tempFloat));

    //P2
    tempInt=lineAll[14].mid(26).toInt();
    ui->LE_pA_E->setText(QString::number(tempInt));
    tempFloat=lineAll[15].mid(25).toFloat();
    ui->LE_pA_CTE->setText(QString::number(tempFloat));
    tempInt=lineAll[16].mid(26).toInt();
    ui->LE_pB_E->setText(QString::number(tempInt));
    tempFloat=lineAll[17].mid(25).toFloat();
    ui->LE_pB_CTE->setText(QString::number(tempFloat));
    tempInt=lineAll[18].mid(23).toInt();
    ui->LE_bolt_E->setText(QString::number(tempInt));
    tempFloat=lineAll[19].mid(16).toFloat();
    ui->LE_T0->setText(QString::number(tempFloat));
    tempInt=lineAll[20].mid(14).toInt();
    ui->LE_T1->setText(QString::number(tempInt));
}

void A_MainWindow::on_btn_read_clicked()
{
    QString curPath=QDir::currentPath();//获取系统当前目录
    //调用打开文件对话框打开一个文件
    QString aFileName=QFileDialog::getOpenFileName(this,"打开一个文件",curPath,
                 "文本文件(*.txt);;所有文件(*.*)");

    if (aFileName.isEmpty())
        return; //如果未选择文件，退出

    this->openTextByStream(aFileName); //打开文件
    this->setData_fromPlainTextEdit();
}

//___________计算设置
//先判断是否可以计算
void A_MainWindow::checkData()
{
    float A_W=ui->LE_pA_W->displayText().toFloat();
    float A_t=ui->LE_pA_t->displayText().toFloat();
    float B_W=ui->LE_pB_W->displayText().toFloat();
    float B_t=ui->LE_pB_t->displayText().toFloat();
    float bolt_S=ui->LE_bolt_S->displayText().toFloat();
    float bolt_D=ui->LE_bolt_D->displayText().toFloat();

    int A_E=ui->LE_pA_E->displayText().toInt();
    float A_CTE=ui->LE_pA_CTE->displayText().toFloat();
    int B_E=ui->LE_pB_E->displayText().toInt();
    float B_CTE=ui->LE_pB_CTE->displayText().toFloat();
    int bolt_E=ui->LE_bolt_E->displayText().toInt();

    this->dataError=false;
    if(A_W<1||A_t<=0||B_W<1||B_t<=0||bolt_S<1||bolt_D<1)
    {
        this->dataError=true;
        return;
    }
    if(A_E<1||A_CTE<0||B_E<1||B_CTE<0||bolt_E<0)
    {
        this->dataError=true;
        return;
    }

}
void A_MainWindow::on_btn_cal_clicked()
{
    this->checkData();
    if(this->dataError)
    {
        ui->lab_info->setText("data error");
        //1秒后恢复
        QTimer::singleShot(1000,this,[=](){
            ui->lab_info->clear();
        });
        return;
    }
    if(this->firstUsePy)
    {
        this->firstUsePy=false;

        Py_Initialize();  //进行初始化
        if(!Py_IsInitialized())
        {
            qDebug()<<"Py_IsInitialized is null";
            return;  //如果初始化失败，返回
        }
        //系统目录为Python39的目录，要把py文件放在该目录下
        PyRun_SimpleString("import sys");
        //PyRun_SimpleString("from scipy.optimize import least_squares");
        QString setSysPath = QString("sys.path.append('%1')").arg(QCoreApplication::applicationDirPath());
        PyRun_SimpleString(setSysPath.toStdString().c_str());

        //加载模块，模块名称为文件
        PyObject *pModule = PyImport_ImportModule("improved stiffness method_v1");
        if(!pModule)
        {
            qDebug()<<"pModule is null "; //加载失败可能是py文件的typo导致
            return; //如果加载失败，则返回
        }
        PyObject* pDict = PyModule_GetDict(pModule);
        if(!pDict)
        {
            qDebug()<<"Cant find dictionary";
            return;
        }
        PyObject* pClassCalc = PyDict_GetItemString(pDict, "Solution"); //需要调用的类
        if (!pClassCalc) {
            qDebug()<<"Cant find calc class./n";
            return;
        }
        //得到构造函数而不是类实例
        if(this->pConstruct!=NULL)
        {
            delete this->pConstruct;
            this->pConstruct=NULL;
        }
        this->pConstruct = PyInstanceMethod_New(pClassCalc);
        if (!pConstruct) {
            qDebug()<<"Cant find calc construct./n";
            return;
        }
    }

    //构建类构造函数的参数
    PyObject* cons_args = PyTuple_New(4);
    PyObject* cons_arg1 = PyLong_FromLong(this->boltNum);
    PyObject* cons_arg2 = PyLong_FromLong(this->lapType);
    PyObject* cons_arg3 = PyLong_FromLong(this->boltType);
    PyObject* cons_arg4 = PyLong_FromLong(this->BCtype);
    PyTuple_SetItem(cons_args, 0, cons_arg1);
    PyTuple_SetItem(cons_args, 1, cons_arg2);
    PyTuple_SetItem(cons_args, 2, cons_arg3);
    PyTuple_SetItem(cons_args, 3, cons_arg4);
    //实例化类得到类对象
    PyObject* pInstance=PyObject_CallObject(this->pConstruct,cons_args); //有参构造

    //P1
    float A_W=ui->LE_pA_W->displayText().toFloat();
    float A_t=ui->LE_pA_t->displayText().toFloat();
    float B_W=ui->LE_pB_W->displayText().toFloat();
    float B_t=ui->LE_pB_t->displayText().toFloat();
    float bolt_S=ui->LE_bolt_S->displayText().toFloat();
    float bolt_D=ui->LE_bolt_D->displayText().toFloat();
    int P0=ui->LE_P0->displayText().toInt();
    PyObject_CallMethod(pInstance,"inputParameter_page1","ffffffi",A_W,A_t,B_W,B_t,bolt_S,bolt_D,P0);

    //P2
    int A_E=ui->LE_pA_E->displayText().toInt();
    float A_CTE=ui->LE_pA_CTE->displayText().toFloat();
    int B_E=ui->LE_pB_E->displayText().toInt();
    float B_CTE=ui->LE_pB_CTE->displayText().toFloat();
    int bolt_E=ui->LE_bolt_E->displayText().toInt();
    float T0=ui->LE_T0->displayText().toFloat();
    float T1=ui->LE_T1->displayText().toFloat();
    PyObject_CallMethod(pInstance,"inputParameter_page2","ifififf",A_E,A_CTE,B_E,B_CTE,bolt_E,T0,T1);

    //调用计算函数
    int resLength=3*this->boltNum;
    if(this->resArr!=NULL)
    {
        delete this->resArr;
        this->resArr=NULL;
    }
    this->resArr=new int[resLength];
    PyObject* resultArr=PyObject_CallMethod(pInstance,"boltShear",""); //计算结果,返回一个list
    int resValue=2;
    for(int k=0;k<resLength;k++)
    {
        PyObject* list_element=PyList_GetItem(resultArr,k);
        PyArg_Parse(list_element,"i",&resValue); //注意加引用符号
        this->resArr[k]=resValue;
    }


    //Py_Finalize(); //不结束，否则第三方库的重复调用可能导致程序崩溃

    B_ResultUI *resultPage=new  B_ResultUI;
    resultPage->setData(this->resArr);
    resultPage->drawFig(this->boltNum,this->lapType);
    resultPage->show();
}
